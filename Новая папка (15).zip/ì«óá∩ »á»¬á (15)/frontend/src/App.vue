<template>
  <div class="min-h-screen w-screen bg-gray-50">
    <Login v-if="!isLoggedIn" @login-success="handleLoginSuccess" />
    <Dashboard v-else @logout="handleLogout" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Login from './components/Login.vue'
import Dashboard from './components/Dashboard.vue'

const isLoggedIn = ref(false)

// Sahifa yuklanganda local storage'dan login holatini tekshirish
if (localStorage.getItem('isLoggedIn') === 'true') {
  isLoggedIn.value = true
}

const handleLoginSuccess = () => {
  isLoggedIn.value = true
  localStorage.setItem('isLoggedIn', 'true') // Login bo'lganda holatni saqlash
  console.log('User logged in successfully!')
}

const handleLogout = () => {
  if (confirm('Are you sure you want to logout?')) {
    isLoggedIn.value = false
    localStorage.removeItem('isLoggedIn') // Logout bo'lganda holatni o'chirish
    console.log('User logged out!')
  }
}
</script>

<style>
/* Global CSS ( agar src/index.css yoki src/main.css dan import qilingan bo'lsa kerak emas) */
body {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
/* Keyingi barcha divlar to'g'ri ishlashi uchun html va body ni 100% balandlikka sozlash */
html, body {
  height: 100%;
}
</style>