<template>
  <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full flex flex-col">
    <h3 class="text-lg font-semibold text-gray-900 mb-4">Monthly Student Registrations (Line Chart)</h3>
    <div class="flex-grow">
      <LineChart :chartData="lineChartData" :options="lineChartOptions" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { LineChart } from 'vue-chart-3';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const lineChartData = computed(() => ({
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'New Registrations',
      data: [12, 19, 3, 5, 2, 10],
      fill: false,
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1,
    },
  ],
}));

const lineChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top',
    },
    title: {
      display: false, // Umumiy sarlavhani o'chirib qo'yamiz
      // text: 'Monthly Student Registrations',
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Number of Students',
      },
    },
    x: {
      title: {
        display: true,
        text: 'Month',
      },
    },
  },
};
</script>

<style scoped></style>