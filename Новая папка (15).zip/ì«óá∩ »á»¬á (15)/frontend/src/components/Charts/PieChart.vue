<template>
  <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full flex flex-col">
    <h3 class="text-lg font-semibold text-gray-900 mb-4">Course Category Distribution (Pie Chart)</h3>
    <div class="flex-grow">
      <PieChart :chartData="pieChartData" :options="pieChartOptions" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { PieChart } from 'vue-chart-3';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const pieChartData = computed(() => ({
  labels: ['Programming', 'Design', 'Marketing', 'Business'],
  datasets: [
    {
      data: [30, 20, 25, 25],
      backgroundColor: [
        'rgba(255, 99, 132, 0.7)',
        'rgba(54, 162, 235, 0.7)',
        'rgba(255, 206, 86, 0.7)',
        'rgba(153, 102, 255, 0.7)',
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(153, 102, 255, 1)',
      ],
      borderWidth: 1,
    },
  ],
}));

const pieChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'right', // Legendani o'ngda joylashtirish
    },
    title: {
      display: false, // Umumiy sarlavhani o'chirib qo'yamiz
      // text: 'Course Category Distribution',
    },
  },
};
</script>

<style scoped></style>