<template>
  <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full flex flex-col">
    <h3 class="text-lg font-semibold text-gray-900 mb-4">Students by Course (Bar Chart)</h3>
    <div class="flex-grow"> <BarChart :chartData="barChartData" :options="barChartOptions" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { BarChart } from 'vue-chart-3';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const barChartData = computed(() => ({
  labels: ['Math', 'Science', 'History', 'Art', 'CST'],
  datasets: [
    {
      label: 'Number of Students',
      data: [65, 59, 80, 81, 56],
      backgroundColor: [
        'rgba(255, 99, 132, 0.6)',
        'rgba(54, 162, 235, 0.6)',
        'rgba(255, 206, 86, 0.6)',
        'rgba(75, 192, 192, 0.6)',
        'rgba(153, 102, 255, 0.6)',
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)',
      ],
      borderWidth: 1,
    },
  ],
}));

const barChartOptions = {
  responsive: true,
  maintainAspectRatio: false, // Konteyner balandligiga moslashadi
  plugins: {
    legend: {
      position: 'top', // Legendani tepada joylashtirish
    },
    title: {
      display: false, // Umumiy sarlavhani o'chirib qo'yamiz, chunki bizda h3 yorlig'i bor
      // text: 'Student Enrollment by Course', // Agar kerak bo'lsa yoqish mumkin
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Number of Students', // Y-o'qi sarlavhasi
      },
    },
    x: {
      title: {
        display: true,
        text: 'Course', // X-o'qi sarlavhasi
      },
    },
  },
};
</script>

<style scoped></style>