<template>
  <div class="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-full flex flex-col">
    <h3 class="text-lg font-semibold text-gray-900 mb-4">Payment Status (Doughnut Chart)</h3>
    <div class="flex-grow">
      <DoughnutChart :chartData="doughnutChartData" :options="doughnutChartOptions" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { DoughnutChart } from 'vue-chart-3';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

const doughnutChartData = computed(() => ({
  labels: ['Paid', 'Pending', 'Overdue'],
  datasets: [
    {
      data: [70, 20, 10],
      backgroundColor: [
        'rgba(75, 192, 192, 0.7)', // Paid (Greenish)
        'rgba(255, 206, 86, 0.7)',  // Pending (Yellowish)
        'rgba(255, 99, 132, 0.7)', // Overdue (Reddish)
      ],
      borderColor: [
        'rgba(75, 192, 192, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(255, 99, 132, 1)',
      ],
      borderWidth: 1,
    },
  ],
}));

const doughnutChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'right', // Legendani o'ngda joylashtirish
    },
    title: {
      display: false, // Umumiy sarlavhani o'chirib qo'yamiz
      // text: 'Overall Payment Status',
    },
  },
};
</script>

<style scoped></style>