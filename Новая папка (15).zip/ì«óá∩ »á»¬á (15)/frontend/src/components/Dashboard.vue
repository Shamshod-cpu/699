<template>
  <div class="flex h-screen bg-gray-50">
    <div class="w-72 bg-white border-r border-gray-200 flex flex-col">
      <div class="p-6 border-b border-gray-200 flex-shrink-0">
        <h2 class="text-lg font-bold text-gray-800">CRUD OPERATIONS</h2>
      </div>

      <div class="p-6 border-b border-gray-200 text-center flex-shrink-0">
        <div class="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
          <span class="text-white text-xl font-bold">KM</span>
        </div>
        <h3 class="text-lg font-semibold text-gray-800">Karthi Madesh</h3>
        <p class="text-sm text-orange-500 font-medium">Admin</p>
      </div>

      <nav class="flex-1 p-4 overflow-y-auto">
        <ul class="space-y-2">
          <li>
            <a href="#" @click.prevent="setCurrentPage('home')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'home' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">🏠</span>
              Home
            </a>
          </li>
          <li>
            <a href="#" @click.prevent="setCurrentPage('course')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'course' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">📚</span>
              Course
            </a>
          </li>
          <li>
            <a href="#" @click.prevent="setCurrentPage('students')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'students' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">👥</span>
              Students
            </a>
          </li>
          <li>
            <a href="#" @click.prevent="setCurrentPage('payment')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'payment' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">💳</span>
              Payment
            </a>
          </li>
          <li>
            <a href="#" @click.prevent="setCurrentPage('report')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'report' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">📊</span>
              Report
            </a>
          </li>
          <li>
            <a href="#" @click.prevent="setCurrentPage('settings')"
               class="flex items-center px-4 py-3 rounded-lg transition-all duration-200"
               :class="currentPage === 'settings' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-100'">
              <span class="mr-3 text-lg">⚙️</span>
              Settings
            </a>
          </li>
        </ul>
      </nav>

      <div class="p-4 border-t border-gray-200 flex-shrink-0">
        <button @click="handleLogout" class="flex items-center w-full px-4 py-3 text-gray-600 rounded-lg border border-gray-200 hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-all duration-200">
          <span class="mr-3 text-lg">🚪</span>
          Logout
        </button>
      </div>
    </div>

    <div class="flex-1 flex flex-col overflow-hidden">
      <div class="bg-white border-b border-gray-200 p-6 flex-shrink-0">
        <div class="flex items-center justify-between">
          <div class="relative flex-1 max-w-md">
            <input
              type="text"
              v-model="searchQuery"
              @input="handleSearch"
              placeholder="Search..."
              class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
            <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">🔍</span>
          </div>
          <div class="flex items-center gap-3 ml-6">
            <button class="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">🔔</button>
            <button class="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">👤</button>
          </div>
        </div>
      </div>

      <div class="flex-1 overflow-auto p-6">
        <div v-if="currentPage === 'home'">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div
              v-for="stat in filteredStats"
              :key="stat.label"
              class="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200"
              :class="{ 'bg-gradient-to-br from-orange-400 to-orange-600 text-white border-orange-500': stat.highlight }"
            >
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <div class="w-12 h-12 rounded-lg flex items-center justify-center text-2xl"
                       :class="{
                          'bg-blue-100': stat.iconClass === 'students' && !stat.highlight,
                          'bg-green-100': stat.iconClass === 'courses' && !stat.highlight,
                          'bg-yellow-100': stat.iconClass === 'payments' && !stat.highlight,
                          'bg-white bg-opacity-20': stat.highlight
                        }">
                    {{ stat.icon }}
                  </div>
                </div>
                <div class="ml-4">
                  <p class="text-sm font-medium" :class="stat.highlight ? 'text-white text-opacity-80' : 'text-gray-500'">
                    {{ stat.label }}
                  </p>
                  <p class="text-2xl font-bold" :class="stat.highlight ? 'text-white' : 'text-gray-900'">
                    {{ stat.number }}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <BarChart class="h-96 w-full" />
            <DoughnutChart class="h-96 w-full" />
            <LineChart class="h-96 w-full" />
            <PieChart class="h-96 w-full" />
          </div>
          </div>

        <Students v-else-if="currentPage === 'students'" :searchQuery="searchQuery" />

        <Payment v-else-if="currentPage === 'payment'" :searchQuery="searchQuery" />

        <div v-else class="flex flex-col items-center justify-center h-96 text-center">
          <div class="text-8xl mb-6">🚧</div>
          <h2 class="text-3xl font-bold text-gray-900 mb-4">{{ currentPage.charAt(0).toUpperCase() + currentPage.slice(1) }} Page</h2>
          <p class="text-gray-600">This page is under construction. Coming soon!</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import Students from './Students.vue'
import Payment from './Payment.vue'
// Chart komponentlarini import qilish
import BarChart from './charts/BarChart.vue'
import DoughnutChart from './charts/DoughnutChart.vue'
import LineChart from './charts/LineChart.vue'
import PieChart from './charts/PieChart.vue'

const emit = defineEmits(['logout'])

const searchQuery = ref('')
const currentPage = ref('home') // Default sahifa 'home'

const stats = ref([
  {
    id: 1,
    label: 'Students',
    number: '243',
    icon: '🎓',
    iconClass: 'students',
    highlight: false
  },
  {
    id: 2,
    label: 'Course',
    number: '13',
    icon: '📖',
    iconClass: 'courses',
    highlight: false
  },
  {
    id: 3,
    label: 'Payments',
    number: 'INR 556,000',
    icon: '💰',
    iconClass: 'payments',
    highlight: false
  },
  {
    id: 4,
    label: 'Users',
    number: '3',
    icon: '👥',
    iconClass: 'users',
    highlight: true
  }
])

// activities ma'lumotlarini endi home sahifasida ishlatilmaydi, lekin qoldirildi.
const activities = ref([
  {
    id: 1,
    icon: '👤',
    text: 'New student registered',
    time: '2 minutes ago'
  },
  {
    id: 2,
    icon: '💳',
    text: 'Payment received',
    time: '5 minutes ago'
  },
  {
    id: 3,
    icon: '📚',
    text: 'New course added',
    time: '1 hour ago'
  }
])

const filteredStats = computed(() => {
  if (!searchQuery.value) return stats.value
  return stats.value.filter(stat =>
    stat.label.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

// filteredActivities endi ishlatilmaydi, lekin qoldirildi.
const filteredActivities = computed(() => {
  if (!searchQuery.value) return activities.value
  return activities.value.filter(activity =>
    activity.text.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const setCurrentPage = (page) => {
  currentPage.value = page
  searchQuery.value = '' // Sahifa o'zgarganda qidiruv so'rovini tozalash
}

const handleSearch = () => {
  // Qidiruv mantig'i allqachon computed propertylarda bor
  console.log('Searching for:', searchQuery.value, 'on page:', currentPage.value)
}

const handleLogout = () => {
  if (confirm('Are you sure you want to logout?')) {
    emit('logout')
  }
}
</script>

<style scoped>
/* Faqat shu komponentga tegishli stillar */
.h-96 {
  height: 24rem; /* Tailwind h-96 = 24rem */
}
</style>