<template>
  <div class="h-full flex flex-col">
    <div class="flex items-center justify-between mb-6 flex-shrink-0">
      <h1 class="text-2xl font-bold text-gray-900">Payment Details</h1>
      </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 flex-1 flex flex-col overflow-hidden">
      <div class="grid grid-cols-6 gap-4 p-4 bg-gray-50 border-b border-gray-200 font-semibold text-gray-700 text-sm flex-shrink-0">
        <div>Name</div>
        <div>Payment Schedule</div>
        <div>Bill Number</div>
        <div>Amount Paid</div>
        <div>Balance Amount</div>
        <div>Date</div>
        <div class="sr-only">Actions</div>
      </div>

      <div class="flex-1 overflow-y-auto">
        <div
          v-for="payment in filteredPayments"
          :key="payment.id"
          class="grid grid-cols-6 gap-4 p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150"
        >
          <div class="flex items-center gap-3">
            <span class="font-medium text-gray-900">{{ payment.name }}</span>
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ payment.schedule }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ payment.billNumber }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ payment.amountPaid }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ payment.balanceAmount }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ payment.date }}
          </div>

          <div class="flex items-center justify-end pr-2">
            <button class="p-2 text-orange-500 hover:bg-orange-50 rounded-full transition-colors duration-150" title="View Details">
              &#x1F517; </button>
          </div>
        </div>

        <div v-if="searchQuery && filteredPayments.length === 0" class="text-center py-12">
          <div class="text-6xl mb-4">🔍</div>
          <p class="text-gray-500">No results found for "{{ searchQuery }}"</p>
        </div>
        <div v-else-if="!searchQuery && payments.length === 0" class="text-center py-12">
          <div class="text-6xl mb-4">😔</div>
          <p class="text-gray-500">No payment records available.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  searchQuery: {
    type: String,
    default: ''
  }
})

const payments = ref([
  {
    id: 1,
    name: 'Karthi',
    schedule: 'First',
    billNumber: '00012223',
    amountPaid: 'INR 35,000',
    balanceAmount: 'INR 55,000',
    date: '08-Dec, 2021'
  },
  {
    id: 2,
    name: 'Karthi',
    schedule: 'Second',
    billNumber: '00012224',
    amountPaid: 'INR 35,000',
    balanceAmount: 'INR 20,000',
    date: '15-Jan, 2022'
  },
  {
    id: 3,
    name: 'John',
    schedule: 'First',
    billNumber: '00012225',
    amountPaid: 'INR 40,000',
    balanceAmount: 'INR 60,000',
    date: '01-Dec, 2021'
  },
  {
    id: 4,
    name: 'Sarah',
    schedule: 'Full',
    billNumber: '00012226',
    amountPaid: 'INR 100,000',
    balanceAmount: 'INR 0',
    date: '20-Nov, 2021'
  },
  {
    id: 5,
    name: 'Mike',
    schedule: 'First',
    billNumber: '00012227',
    amountPaid: 'INR 30,000',
    balanceAmount: 'INR 45,000',
    date: '05-Jan, 2022'
  },
  {
    id: 6,
    name: 'Emily',
    schedule: 'First',
    billNumber: '00012228',
    amountPaid: 'INR 25,000',
    balanceAmount: 'INR 30,000',
    date: '10-Feb, 2022'
  },
])

const filteredPayments = computed(() => {
  if (!props.searchQuery) return payments.value

  const query = props.searchQuery.toLowerCase()
  return payments.value.filter(payment =>
    payment.name.toLowerCase().includes(query) ||
    payment.schedule.toLowerCase().includes(query) ||
    payment.billNumber.includes(query) ||
    payment.amountPaid.toLowerCase().includes(query) ||
    payment.balanceAmount.toLowerCase().includes(query) ||
    payment.date.toLowerCase().includes(query)
  )
})
</script>

<style scoped>
/* Faqat shu komponentga tegishli stillar */
</style>