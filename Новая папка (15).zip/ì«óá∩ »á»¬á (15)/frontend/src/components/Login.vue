<template>
  <div class="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-orange-400 to-orange-600 p-4 overflow-y-auto">
    <div class="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl my-4">
      <div class="text-center mb-6">
        <div class="flex items-center justify-center gap-3 mb-3">
          <div class="text-2xl">🔐</div>
          <h1 class="text-lg font-bold text-gray-800 tracking-wide">CRUD OPERATIONS</h1>
        </div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">SIGN IN</h2>
        <p class="text-sm text-gray-600">Enter your credentials to access your account</p>
      </div>
      
      <form @submit.prevent="handleSubmit" class="space-y-4">
        <div>
          <label for="email" class="block text-sm font-semibold text-gray-700 mb-1">Email Address</label>
          <div class="relative">
            <input
              id="email"
              v-model="email"
              type="email"
              class="w-full px-4 py-2.5 border-2 rounded-xl text-sm transition-all duration-200 focus:outline-none focus:ring-0"
              :class="{ 
                'border-red-400 focus:border-red-500': emailError, 
                'border-green-400 focus:border-green-500': email && !emailError,
                'border-gray-300 focus:border-orange-500': !emailError && !email
              }"
              placeholder="Enter your email address"
              @blur="validateEmail"
              @input="validateEmail"
              required
            />
            <div class="absolute right-3 top-1/2 transform -translate-y-1/2">
              <span v-if="email && !emailError" class="text-green-500 text-sm">✓</span>
              <span v-if="emailError" class="text-red-500 text-sm">✗</span>
            </div>
          </div>
          <div v-if="emailError" class="text-xs text-red-500 mt-1">{{ emailError }}</div>
          <div v-if="email && !emailError" class="text-xs text-green-500 mt-1">Valid email address</div>
        </div>

        <div>
          <label for="password" class="block text-sm font-semibold text-gray-700 mb-1">Password</label>
          <div class="relative">
            <input
              id="password"
              v-model="password"
              :type="showPassword ? 'text' : 'password'"
              class="w-full px-4 py-2.5 pr-12 border-2 rounded-xl text-sm transition-all duration-200 focus:outline-none focus:ring-0"
              :class="{ 
                'border-red-400 focus:border-red-500': passwordErrors.length > 0, 
                'border-green-400 focus:border-green-500': password && passwordErrors.length === 0,
                'border-gray-300 focus:border-orange-500': passwordErrors.length === 0 && !password
              }"
              placeholder="Enter your password"
              @input="validatePassword"
              required
            />
            <button
              type="button"
              class="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded hover:bg-gray-100 transition-colors"
              @click="togglePassword"
            >
              <span class="text-lg">{{ showPassword ? '👁️' : '👁️‍🗨️' }}</span>
            </button>
          </div>
          
          <div class="mt-2 p-2 bg-gray-50 rounded-lg border text-xs">
            <p class="font-semibold text-gray-700 mb-1">Password must contain:</p>
            <div class="grid grid-cols-1 gap-1">
              <div class="flex items-center gap-2" :class="passwordChecks.length ? 'text-green-600' : 'text-gray-500'">
                <span class="w-3 text-center">{{ passwordChecks.length ? '✓' : '○' }}</span>
                At least 8 characters
              </div>
              <div class="flex items-center gap-2" :class="passwordChecks.uppercase ? 'text-green-600' : 'text-gray-500'">
                <span class="w-3 text-center">{{ passwordChecks.uppercase ? '✓' : '○' }}</span>
                One uppercase letter
              </div>
              <div class="flex items-center gap-2" :class="passwordChecks.lowercase ? 'text-green-600' : 'text-gray-500'">
                <span class="w-3 text-center">{{ passwordChecks.lowercase ? '✓' : '○' }}</span>
                One lowercase letter
              </div>
              <div class="flex items-center gap-2" :class="passwordChecks.number ? 'text-green-600' : 'text-gray-500'">
                <span class="w-3 text-center">{{ passwordChecks.number ? '✓' : '○' }}</span>
                One number
              </div>
              <div class="flex items-center gap-2" :class="passwordChecks.special ? 'text-green-600' : 'text-gray-500'">
                <span class="w-3 text-center">{{ passwordChecks.special ? '✓' : '○' }}</span>
                One special character
              </div>
            </div>
          </div>
        </div>

        <div class="flex items-center py-2">
          <label class="flex items-center gap-3 text-sm text-gray-700 cursor-pointer">
            <input type="checkbox" v-model="rememberMe" class="hidden">
            <div class="w-4 h-4 border-2 border-gray-300 rounded flex items-center justify-center transition-all" :class="{ 'bg-orange-500 border-orange-500': rememberMe }">
              <span v-if="rememberMe" class="text-white text-xs font-bold">✓</span>
            </div>
            Remember me for 30 days
          </label>
        </div>
        
        <button 
          type="submit" 
          class="w-full bg-gradient-to-r from-orange-400 to-orange-600 text-white py-3 px-6 rounded-xl font-semibold transition-all duration-200 hover:from-orange-500 hover:to-orange-700 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          :disabled="!isFormValid || isLoading"
        >
          <span v-if="isLoading" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
          {{ isLoading ? 'Signing In...' : 'Sign In' }}
        </button>
        
        <div class="text-center text-sm text-gray-600 pt-2">
          <span>Forgot your password? </span>
          <a href="#" @click.prevent="handleForgotPassword" class="text-orange-500 font-semibold hover:text-orange-600 hover:underline">
            Reset password
          </a>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive } from 'vue'

const emit = defineEmits(['login-success'])

const email = ref('')
const password = ref('')
const showPassword = ref(false)
const rememberMe = ref(false)
const isLoading = ref(false)
const emailError = ref('')

const passwordChecks = reactive({
  length: false,
  uppercase: false,
  lowercase: false,
  number: false,
  special: false
})

const passwordErrors = computed(() => {
  const errors = []
  if (password.value && !passwordChecks.length) errors.push('At least 8 characters')
  if (password.value && !passwordChecks.uppercase) errors.push('One uppercase letter')
  if (password.value && !passwordChecks.lowercase) errors.push('One lowercase letter')
  if (password.value && !passwordChecks.number) errors.push('One number')
  if (password.value && !passwordChecks.special) errors.push('One special character')
  return errors
})

const isFormValid = computed(() => {
  return email.value && 
           !emailError.value && 
           password.value && 
           passwordErrors.value.length === 0
})

const validateEmail = () => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!email.value) {
    emailError.value = ''
  } else if (!emailRegex.test(email.value)) {
    emailError.value = 'Please enter a valid email address'
  } else {
    emailError.value = ''
  }
}

const validatePassword = () => {
  const pwd = password.value
  passwordChecks.length = pwd.length >= 8
  passwordChecks.uppercase = /[A-Z]/.test(pwd)
  passwordChecks.lowercase = /[a-z]/.test(pwd)
  passwordChecks.number = /\d/.test(pwd)
  passwordChecks.special = /[!@#$%^&*(),.?":{}|<>]/.test(pwd)
}

const togglePassword = () => {
  showPassword.value = !showPassword.value
}

const handleSubmit = async () => {
  if (!isFormValid.value) return
  
  isLoading.value = true
  
  try {
    // Haqiqiy ilovada, bu yerda autentifikatsiya API chaqiruvini bajaring
    // Masalan: await axios.post('/api/login', { email: email.value, password: password.value });
    await new Promise(resolve => setTimeout(resolve, 2000)) // 2 soniya kutish simulyatsiyasi
    emit('login-success') // Agar muvaffaqiyatli bo'lsa, "login-success" eventini yuboramiz
  } catch (error) {
    console.error('Login failed:', error)
    alert('Login failed. Please try again.')
  } finally {
    isLoading.value = false
  }
}

const handleForgotPassword = () => {
  alert('Password reset link will be sent to your email')
}
</script>

<style scoped>
/* Faqat shu komponentga tegishli stillar */
</style>