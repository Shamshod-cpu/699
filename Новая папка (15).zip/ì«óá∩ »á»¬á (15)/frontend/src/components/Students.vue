<template>
  <div class="h-full flex flex-col">
    <div class="flex items-center justify-between mb-6 flex-shrink-0">
      <h1 class="text-2xl font-bold text-gray-900">Students List</h1>
      <button @click="showAddModal = true" class="bg-gradient-to-r from-orange-400 to-orange-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-500 hover:to-orange-700 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center gap-2">
        <span class="text-lg">➕</span>
        ADD NEW STUDENT
      </button>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 flex-1 flex flex-col overflow-hidden">
      <div class="grid grid-cols-6 gap-4 p-4 bg-gray-50 border-b border-gray-200 font-semibold text-gray-700 text-sm flex-shrink-0">
        <div>Name</div>
        <div>Email</div>
        <div>Phone</div>
        <div>Enroll Number</div>
        <div>Date of admission</div>
        <div>Actions</div>
      </div>

      <div class="flex-1 overflow-y-auto">
        <div
          v-for="student in filteredStudents"
          :key="student.id"
          class="grid grid-cols-6 gap-4 p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150"
        >
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md" :style="{ background: getAvatarColor(student.name) }">
              {{ getInitials(student.name) }}
            </div>
            <span class="font-medium text-gray-900">{{ student.name }}</span>
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ student.email }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ student.phone }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ student.enrollNumber }}
          </div>

          <div class="flex items-center text-sm text-gray-600">
            {{ student.dateOfAdmission }}
          </div>

          <div class="flex items-center gap-2">
            <button @click="editStudent(student)" class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-150" title="Edit">
              ✏️
            </button>
            <button @click="deleteStudent(student.id)" class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-150" title="Delete">
              🗑️
            </button>
          </div>
        </div>

        <div v-if="searchQuery && filteredStudents.length === 0" class="text-center py-12">
          <div class="text-6xl mb-4">🔍</div>
          <p class="text-gray-500">No results found for "{{ searchQuery }}"</p>
        </div>
        <div v-else-if="!searchQuery && students.length === 0" class="text-center py-12">
          <div class="text-6xl mb-4">😔</div>
          <p class="text-gray-500">No student records available. Add a new student!</p>
        </div>
      </div>
    </div>

    <div v-if="showAddModal || showEditModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" @click="closeModal">
      <div class="bg-white rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto" @click.stop>
        <div class="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 class="text-xl font-bold text-gray-900">{{ showEditModal ? 'Edit Student' : 'Add New Student' }}</h2>
          <button @click="closeModal" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
        </div>

        <form @submit.prevent="saveStudent" class="p-6 space-y-4">
          <div>
            <label for="name" class="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
            <input
              id="name"
              v-model="currentStudent.name"
              type="text"
              required
              placeholder="Enter student name"
              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
            <input
              id="email"
              v-model="currentStudent.email"
              type="email"
              required
              placeholder="Enter email address"
              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label for="phone" class="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
            <input
              id="phone"
              v-model="currentStudent.phone"
              type="tel"
              required
              placeholder="Enter phone number"
              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label for="enrollNumber" class="block text-sm font-semibold text-gray-700 mb-2">Enroll Number</label>
            <input
              id="enrollNumber"
              v-model="currentStudent.enrollNumber"
              type="text"
              required
              placeholder="Enter enroll number"
              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div>
            <label for="dateOfAdmission" class="block text-sm font-semibold text-gray-700 mb-2">Date of Admission</label>
            <input
              id="dateOfAdmission"
              v-model="currentStudent.dateOfAdmission"
              type="date"
              required
              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          <div class="flex gap-3 pt-6 border-t border-gray-200">
            <button type="button" @click="closeModal" class="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-150">
              Cancel
            </button>
            <button type="submit" class="flex-1 px-4 py-3 bg-gradient-to-r from-orange-400 to-orange-600 text-white rounded-lg hover:from-orange-500 hover:to-orange-700 transition-all duration-150">
              {{ showEditModal ? 'Update Student' : 'Add Student' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, reactive } from 'vue'

const props = defineProps({
  searchQuery: {
    type: String,
    default: ''
  }
})

const showAddModal = ref(false)
const showEditModal = ref(false)

const currentStudent = reactive({
  id: null,
  name: '',
  email: '',
  phone: '',
  enrollNumber: '',
  dateOfAdmission: ''
})

const avatarColors = [
  'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
  'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
  'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
  'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
  'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
  'linear-gradient(135deg, #ff8a80 0%, #ea6100 100%)',
  'linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%)',
  'linear-gradient(135deg, #a6c1ee 0%, #fbc2eb 100%)',
  'linear-gradient(135deg, #fdbb2d 0%, #22c1c3 100%)',
  'linear-gradient(135deg, #ee9ca7 0%, #ffdde1 100%)',
  'linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%)',
  'linear-gradient(135deg, #ffeaa7 0%, #fab1a0 100%)'
]

const students = ref([
  {
    id: 1,
    name: 'Karthi Madesh',
    email: 'karthi@gmail.com',
    phone: '7904477760',
    enrollNumber: '1234567890477760',
    dateOfAdmission: '08-Dec, 2021'
  },
  {
    id: 2,
    name: 'John Smith',
    email: 'john@gmail.com',
    phone: '7904477761',
    enrollNumber: '1234567890477761',
    dateOfAdmission: '10-Dec, 2021'
  },
  {
    id: 3,
    name: 'Sarah Johnson',
    email: 'sarah@gmail.com',
    phone: '7904477762',
    enrollNumber: '1234567890477762',
    dateOfAdmission: '12-Dec, 2021'
  },
  {
    id: 4,
    name: 'Mike Wilson',
    email: 'mike@gmail.com',
    phone: '7904477763',
    enrollNumber: '1234567890477763',
    dateOfAdmission: '15-Dec, 2021'
  },
  {
    id: 5,
    name: 'Emily Davis',
    email: 'emily@gmail.com',
    phone: '7904477764',
    enrollNumber: '1234567890477764',
    dateOfAdmission: '18-Dec, 2021'
  },
  {
    id: 6,
    name: 'Alex Rodriguez',
    email: 'alex@gmail.com',
    phone: '7904477765',
    enrollNumber: '1234567890477765',
    dateOfAdmission: '20-Dec, 2021'
  },
  {
    id: 7,
    name: 'Lisa Chen',
    email: 'lisa@gmail.com',
    phone: '7904477766',
    enrollNumber: '1234567890477766',
    dateOfAdmission: '22-Dec, 2021'
  }
])

const getInitials = (name) => {
  return name
    .split(' ')
    .map(word => word.charAt(0).toUpperCase())
    .join('')
    .substring(0, 2)
}

const getAvatarColor = (name) => {
  const index = name.charCodeAt(0) % avatarColors.length
  return avatarColors[index]
}

const filteredStudents = computed(() => {
  if (!props.searchQuery) return students.value

  return students.value.filter(student =>
    student.name.toLowerCase().includes(props.searchQuery.toLowerCase()) ||
    student.email.toLowerCase().includes(props.searchQuery.toLowerCase()) ||
    student.phone.includes(props.searchQuery) ||
    student.enrollNumber.includes(props.searchQuery)
  )
})

const resetCurrentStudent = () => {
  currentStudent.id = null
  currentStudent.name = ''
  currentStudent.email = ''
  currentStudent.phone = ''
  currentStudent.enrollNumber = ''
  currentStudent.dateOfAdmission = ''
}

const closeModal = () => {
  showAddModal.value = false
  showEditModal.value = false
  resetCurrentStudent()
}

const editStudent = (student) => {
  currentStudent.id = student.id
  currentStudent.name = student.name
  currentStudent.email = student.email
  currentStudent.phone = student.phone
  currentStudent.enrollNumber = student.enrollNumber
  currentStudent.dateOfAdmission = student.dateOfAdmission
  showEditModal.value = true
}

const deleteStudent = (studentId) => {
  if (confirm('Are you sure you want to delete this student?')) {
    const index = students.value.findIndex(s => s.id === studentId)
    if (index > -1) {
      students.value.splice(index, 1)
      alert('Student deleted successfully!')
    }
  }
}

const saveStudent = () => {
  if (showEditModal.value) {
    const index = students.value.findIndex(s => s.id === currentStudent.id)
    if (index > -1) {
      students.value[index] = { ...currentStudent }
      alert('Student updated successfully!')
    }
  } else {
    const newStudent = {
      ...currentStudent,
      id: Date.now() // Vaqt asosida unikal ID yaratish
    }
    students.value.push(newStudent)
    alert('Student added successfully!')
  }

  closeModal()
}
</script>

<style scoped>
/* Faqat shu komponentga tegishli stillar */
</style>